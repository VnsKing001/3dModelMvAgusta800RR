const defaultOptions = {
  colorCircle: false,
  colorSlice: '#00a1ff',
  end: 264,
  fontColor: '#365b74',
  fontSize: '1.6rem',
  fontWeight: 400,
  lineargradient: false,
  number: true,
  opacity: 10,
  round: false,
  size: 200,
  stroke: 10,
};

export default defaultOptions;
